/**
 * la liste des couleurs
 * 
 * @author belaid
 *
 */
public enum Couleur {

	OR, ARGENT;
}
