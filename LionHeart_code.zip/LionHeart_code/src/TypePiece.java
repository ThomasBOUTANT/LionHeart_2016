/**
 * la liste des pieces du jeu
 * 
 * @author belaid
 *
 */
public enum TypePiece {

	ARCHER, CAVALIER, ROI, SOLDAT;
}
