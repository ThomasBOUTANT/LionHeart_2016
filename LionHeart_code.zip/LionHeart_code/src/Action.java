
/**
 * la liste des actions possibles
 * 
 * @author boutant
 *
 */
public enum Action {

	Attaquer, Deplacer, Tourner;
	
}
